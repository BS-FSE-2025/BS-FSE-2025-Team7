from django.contrib import admin
from .models import Compliment

# Define a model admin class
class ComplimentAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'phone_number', 'description', 'latitude', 'longitude')  # Fields to display in the list view
    search_fields = ('name', 'email')  # Fields to search in the admin interface
    list_filter = ('latitude', 'longitude')  # Add a filter for latitude and longitude (if desired)
    ordering = ('name',)  # Order the entries by the 'name' field

# Register your model and the admin class
admin.site.register(Compliment, ComplimentAdmin)
