from django.shortcuts import render, redirect
from .forms import ComplimentForm

def add_compliment(request):
    if request.method == 'POST':
        form = ComplimentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('thank_you')  # Redirect to a thank-you page or wherever
    else:
        form = ComplimentForm()

    return render(request, 'add_compliment.html', {'form': form})
