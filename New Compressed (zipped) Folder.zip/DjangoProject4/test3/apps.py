# test3/apps.py
from django.apps import AppConfig

class Test3Config(AppConfig):
    name = 'test3'
