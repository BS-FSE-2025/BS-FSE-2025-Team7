from django import forms
from .models import Compliment

class ComplimentForm(forms.ModelForm):
    class Meta:
        model = Compliment
        fields = ['name', 'email', 'phone_number', 'description', 'latitude', 'longitude']
